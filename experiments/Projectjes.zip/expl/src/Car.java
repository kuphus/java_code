public class Car {

    public static void main(String[] args) {
        System.out.println("Hello");
    }

    static String color;

    public void setColor(String x){
        this.color = x;
    }

    public static String getColor(){
        return this.color;
    }


    public void replaceDoor(Door oudeDeur, Door nieuwDeur){
        Door oudeDeur = blablabla;
        Door nieuwDeur = yadadadada;

    }

    public void Function(String woord, boolean isDatZo, int getal){
        char yada = (char)getal;
        if(isDatZo){
            for(int index = 0; index <= getal; index++){
                System.out.println(woord.charAt(index));
                searchString(woord, yada)
            }
        }
    }


    public int searchString(String toBeSearched, char toBeFound){
        boolean check;
        int index;
        for(index = 0; index < toBeSearched.length(); index++){
            check = toBeSearched.charAt(index) == toBeFound;
            if(check){
                return index;
            }
        }
        Function(toBeSearched, check, index);
        return -1;
    }



}



Car bmw = new Car();
Door x = new Door();

String naam = "Henk";
boolean waar = true;
int nummer = 15000;


bmw.replaceDoor(x, x);

bmw.Function(naam, waar, nummer);








public class Main{

    public static void main(String[] args){
        Game game1 = new Game("Galgje");
        game1.start(level x, character Z);
        Game game2 = new Game(3,"tset");

    }
}


public class Game{

    String name;
    private boolean won = false;

    public Game(String name){
        this.name = name;
    }

    public Game(){

    }

    public Game(int x, String s){

    }

    public void start(){
        do{
        ask for a letter;
        check letter;
        if word == word -> won = true
        }while(!won)
    }


}

public class Level{

    int breedte;
    int hoogte;
    int diepte;

    public Level(int breedte, int hoogte, int diepte){
        this.breedte = breedte;
        this.diepte = diepte;
        this.hoogte = hoogte;
    }

    public Level (int breedte, int hoogte){
        int diepte = 100;
        this(breedte, hoogte, diepte);
    }

    public Level(int diepte){
        this(100,100,diepte);
    }

    public Level(int hoogte){

    }

}



