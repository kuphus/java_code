import java.util.*;
class a {
  static public void main(String[] __A_V_){
    String $ = "";
    System.out.println(Arrays.toString(__A_V_));
    for(int x=0; ++x < __A_V_.length;)
      $ += __A_V_[x];
    System.out.println($);
  }
}