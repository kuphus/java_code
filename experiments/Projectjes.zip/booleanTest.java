class booleanTest{
  public static void main(String[] args){
    int x = 2;


    public boolean method(){
      if(x==3){
        return true;
      }
      return false;
    }

    System.out.print(method());
  }
}