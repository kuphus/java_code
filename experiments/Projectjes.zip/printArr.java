class printArr{
  public static void main(String[] args){
    int[] intArr = {1,2,3,4,5};
    System.out.println(intArr);
  }
}